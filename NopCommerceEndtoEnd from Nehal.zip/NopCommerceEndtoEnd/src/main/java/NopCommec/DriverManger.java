package NopCommec;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;

import java.util.concurrent.TimeUnit;

/**
 * Hello world!
 *
 */
public class DriverManger
{

    protected static WebDriver driver;

    public DriverManger(){
        PageFactory.initElements(driver,this);
    }

    public static void openBrowser()
    {
        driver=new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.get("http://demo.nopcommerce.com");

    }

    public static void closeBrowser()
    {
       driver.quit();
    }

}
