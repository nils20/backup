package NopCommec;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by User on 23/11/2016.
 */
public class CartPage extends DriverManger{

@FindBy(id = "termsofservice")
    private WebElement _termOfService;

    @FindBy(id = "checkout")
private WebElement _checkOut;

    @FindBy(className = "title")
    private WebElement _checkoutSuccess;


    public void userCheckout()
    {
        Utility.cliclOnElement(_termOfService);
        Utility.cliclOnElement(_checkOut);

        Assert.assertEquals("Billing address",Utility.getText(_checkoutSuccess));
        System.out.println("your check out successfully");
    }





}
