package NopCommec;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by User on 22/11/2016.
 */
public class MainPage extends DriverManger{


    @FindBy(name = "Register")
    private WebElement _register;

    @FindBy(linkText= "Computers")
    private WebElement _computerHeader;


    @FindBy(xpath = "//li/ul/li/a")
    private WebElement _destopHeader;

    @FindBy(xpath = "//div[2]/ul/li[2]/a")
    private WebElement _electronicsHeader;

    @FindBy(xpath = "//li[2]/ul/li[2]/a")
    private WebElement _cellPhone;

    @FindBy(className = "current-item")
    private WebElement _actualResult;

    @FindBy(css ="span.cart-label")
    private WebElement _shoppingcart;

    @FindBy(css = "input.button-1.cart-button")
    private WebElement _cart;

    @FindBy(css = "span.close")
    private WebElement _closebox;

    @FindBy(xpath = "//dt[@id='checkout_attribute_label_1']/label")
private WebElement _actualCart;
    public void productOfDesktops()
    {
        Utility.cliclOnElement(_computerHeader);
        Utility.cliclOnElement(_destopHeader);

        Assert.assertEquals("Desktops",Utility.getText(_actualResult));
        System.out.println("User on the Desktops page");
    }
    public void productOfElectronics()
    {
        Utility.cliclOnElement(_electronicsHeader);
        Utility.cliclOnElement(_cellPhone);

        Assert.assertEquals("Cell phones",Utility.getText(_actualResult));
        System.out.println("User on the Cell Phones page");
    }

    public void cart() throws InterruptedException {
        Utility.cliclOnElement(_closebox);
        Utility.mouseHoveraction(_shoppingcart);
        Utility.cliclOnElement(_cart);
        System.out.println("product Add");

       Assert.assertEquals("Gift wrapping",Utility.getText(_actualCart));
       System.out.println("user click on cart");

    }


    }

