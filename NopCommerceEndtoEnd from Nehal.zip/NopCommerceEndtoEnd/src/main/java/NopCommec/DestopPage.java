package NopCommec;

import org.bouncycastle.asn1.ua.UAObjectIdentifiers;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by User on 22/11/2016.
 */
public class DestopPage extends DriverManger{


    @FindBy(xpath = "//div[3]/div/div[2]/h2/a")
    private WebElement _lenova600;

    @FindBy(id = "add-to-cart-button-3")
    private WebElement _addTocart;

    @FindBy(className = "content")
    private WebElement _actualreult;

    public void elementFrom_Desktop () throws InterruptedException {


        Utility.cliclOnElement(_lenova600);
        Utility.cliclOnElement(_addTocart);

        Assert.assertEquals("The product has been added to your shopping cart",Utility.getText(_actualreult));
        System.out.println("The product has been added to your shopping cart");


    }

}
