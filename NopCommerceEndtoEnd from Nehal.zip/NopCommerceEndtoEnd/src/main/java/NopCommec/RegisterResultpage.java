package NopCommec;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.w3c.dom.events.UIEvent;

/**
 * Created by User on 22/11/2016.
 */
public class RegisterResultpage extends DriverManger {

    @FindBy(name = "register-continue")
    private WebElement _continue;
    @FindBy(css ="h2")
    private WebElement _actualResult;


    public void continueFor () throws InterruptedException {
       // Thread.sleep(2000);
          Utility.cliclOnElement(_continue);

        Assert.assertEquals("Welcome to our store",Utility.getText(_actualResult));
        System.out.println("User On Main Page");
       // Thread.sleep(2000);

    }
}