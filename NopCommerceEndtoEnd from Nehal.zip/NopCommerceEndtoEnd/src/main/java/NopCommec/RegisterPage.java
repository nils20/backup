package NopCommec;

import org.apache.http.util.Asserts;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by User on 22/11/2016.
 */
public class RegisterPage extends DriverManger{

//Utility utility=new Utility();

    @FindBy(linkText = "Register")
    private WebElement _register;

    @FindBy(id ="gender-male")
    private WebElement _genderMale;

    @FindBy(id="gender-female")
    private WebElement _genderFemale;

    @FindBy(id = "FirstName")
    private WebElement _firstName;

    @FindBy(id="LastName")
    private WebElement _lastName;

    @FindBy(name = "DateOfBirthDay")
    private WebElement _birthDay;

    @FindBy(name = "DateOfBirthMonth")
    private WebElement _birthMonth;

    @FindBy(name = "DateOfBirthYear")
    private WebElement _birthYear;

    @FindBy(id="Email")
    private WebElement _email;

    @FindBy(id="Company")
    private WebElement _Company;

    @FindBy(id="Password")
    private WebElement _passWord;

    @FindBy(id="ConfirmPassword")
    private WebElement _confirmPassword;

    @FindBy(id = "register-button")
    private WebElement _registerButton;

    @FindBy(className="result")
    private WebElement _actulResult;


public  void registerForm() throws InterruptedException {
    Utility.cliclOnElement(_register);
    Utility.cliclOnElement(_genderMale);
    Utility.typeText(_firstName,"ram");
    Utility.typeText(_lastName,"Rathod");
    Utility.scrollBy(_birthDay,1);
    Utility.scrollBy(_birthMonth,3);
    //Utility.scrollbyVisibleText(_birthMonth,"March");
   // Utility.scrollbyVisibleText(_birthYear,1990);
    Utility.scrollBy(_birthYear,25);
    String email ="ne102"+Utility.randomDate()+"@gmail.com";// virtual email ganareter unique
    Utility.typeText(_email,email);
    System.out.println(email);
    Utility.typeText(_Company,"Actt");
    Utility.typeText(_passWord,"aB12345");
    Utility.typeText(_confirmPassword,"aB12345");
    Utility.cliclOnElement(_registerButton);
//    Thread.sleep(3000);

    Assert.assertEquals("Your registration completed",Utility.getText(_actulResult));

    System.out.println("Test pass for Register  page");



}





}
