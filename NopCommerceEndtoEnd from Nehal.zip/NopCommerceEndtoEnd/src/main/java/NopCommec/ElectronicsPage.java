package NopCommec;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by User on 22/11/2016.
 */
public class ElectronicsPage extends DriverManger {


    @FindBy(css ="h2.product-title > a")
    private WebElement _htcOneM8_A5;

    @FindBy(id = "add-to-cart-button-18")
    private WebElement _addTocart;

    @FindBy(className = "content")
    private WebElement _actualreult;

    public void elementFromElectronicPage () throws InterruptedException {

        Utility.cliclOnElement(_htcOneM8_A5);
        Utility.cliclOnElement(_addTocart);
  //     Thread.sleep(2000);
        Assert.assertEquals("The product has been added to your shopping cart",Utility.getText(_actualreult));
        System.out.println("The product has been added to your shopping cart");

    }



}
