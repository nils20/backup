package NopCommec;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by User on 23/11/2016.
 */
public class BillingPage_1 extends DriverManger {


    @FindBy(id = "BillingNewAddress_CountryId")
    private WebElement _counteryName;

    @FindBy(id = "BillingNewAddress_StateProvinceId")
    private WebElement _stateName;

    @FindBy(id = "BillingNewAddress_City")
    private WebElement _cityName;

    @FindBy(id = "BillingNewAddress_Address1")
    private WebElement _address1;

    @FindBy(id = "BillingNewAddress_Address2")
    private WebElement _address2;

    @FindBy(id = "BillingNewAddress_ZipPostalCode")
    private WebElement _zipCode;
    @FindBy(id = "BillingNewAddress_PhoneNumber")
    private WebElement _phoneNum;
    @FindBy(id = "BillingNewAddress_FaxNumber")
    private WebElement _faxNum;
    @FindBy(css = "input.button-1.new-address-next-step-button")
    private WebElement _continueNext;

    @FindBy(id = "paymentmethod_1")
    private WebElement _paymentMethod;

@FindBy(xpath = "/descendant::strong[contains(text(),'Your order has been successfully processed!')]")
private WebElement _actualResult;

    @FindBy(css = "input.button-1.shipping-method-next-step-button")
    private WebElement _shippingmethod;

    @FindBy(css ="#paymentmethod_1" )
    private WebElement _cickOncard;

    @FindBy(css ="input.button-1.payment-method-next-step-button" )
    private WebElement _payByCard;

    @FindBy(id = "CreditCardType")
    private WebElement _cardType;

    @FindBy(id = "CardholderName")
    private WebElement _cardHolderName;

    @FindBy(id = "CardNumber")
    private WebElement _cardNumber;

    @FindBy(id = "ExpireMonth")
        private WebElement _cardExp;

    @FindBy(id = "ExpireYear")
    private WebElement _cardExpYear;

    @FindBy(id = "CardCode")
    private WebElement _cardCvc;

    @FindBy(css = "input.button-1.payment-info-next-step-button")
    private WebElement  _paymentDone;


@FindBy(css = "input.button-1.confirm-order-next-step-button")
private WebElement _orderCompleted;



    public void billingPage() throws InterruptedException {

             Utility.scrollBy(_counteryName,01);
      //  Thread.sleep(2000);
        Utility.scrollbyVisibleText(_stateName,"Florida");

        Utility.typeText(_cityName,"Miami");
        Utility.typeText(_address2,"North Florida");
        Utility.typeText(_address1,"124 Bill Road");
        Utility.typeText(_zipCode,"457812");
        Utility.typeText(_phoneNum,"0018794511457");
        Utility.typeText(_faxNum,"0018746985467");

        Utility.cliclOnElement(_continueNext);


        Utility.cliclOnElement(_shippingmethod);           //3 : Shipping Methods

        Utility.cliclOnElement(_cickOncard);               //4: Payment Methods
        Utility.cliclOnElement(_payByCard);
     //   Thread.sleep(3000);

         Utility.scrollBy(_cardType,01);                   //5: Payment Process
         Utility.typeText(_cardHolderName,"Ram");
        Utility.typeText(_cardNumber,"5283340681539760");
        Utility.scrollBy(_cardExp,05);
        Utility.scrollBy(_cardExpYear,05);
        Utility.typeText(_cardCvc,"989");
     //   Thread.sleep(3000);
        Utility.cliclOnElement(_paymentDone);
      //  System.out.println("heloooooo");
        Utility.cliclOnElement(_orderCompleted);

        Assert.assertEquals("Your order has been successfully processed!",Utility.getText(_actualResult));
     //   Thread.sleep(10000);
       System.out.println("Thank you");


    }



}
