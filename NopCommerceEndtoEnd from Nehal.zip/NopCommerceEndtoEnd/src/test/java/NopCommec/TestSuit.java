package NopCommec;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

/**
 * Unit test for simple DriverManger.
 */
public class TestSuit extends DriverManger{


@BeforeTest
    public static void open(){
    DriverManger.openBrowser();
}

@AfterTest
    public static void close(){
    DriverManger.closeBrowser();
}


@org.testng.annotations.Test

       public void userBuyEndToEnd() throws InterruptedException {

         RegisterPage registerPage = new RegisterPage();
         RegisterResultpage registerResultpage=new RegisterResultpage();
         MainPage mainPage=new MainPage();
         DestopPage destopPage=new DestopPage();
         ElectronicsPage electronicsPage=new ElectronicsPage();
         CartPage cartPage=new CartPage();
         BillingPage_1 billingPage_1=new BillingPage_1();




         registerPage.registerForm();
         registerResultpage.continueFor();
         mainPage.productOfDesktops();
         destopPage.elementFrom_Desktop();
         mainPage.productOfElectronics();
         electronicsPage.elementFromElectronicPage();
         mainPage.cart();
         cartPage.userCheckout();
         billingPage_1.billingPage();

        }
    }


