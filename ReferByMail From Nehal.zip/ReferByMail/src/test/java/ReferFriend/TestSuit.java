package ReferFriend;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

/**
 * Unit test for simple Utility.
 */
public class TestSuit
    extends DriverManager{


    @BeforeTest
    public static void open(){
        DriverManager.openBrowser();
    }

    @AfterTest
    public static void close(){
       DriverManager.closeBrowser();
    }
@org.testng.annotations.Test
    public void referFriend() throws InterruptedException {

        RegisterPage registerPage = new RegisterPage();

        MainPage mainPage = new MainPage();
        DesktopPage destopPage = new DesktopPage();
    EmailFriend emailFriend=new EmailFriend();



        registerPage.registerForm();

        mainPage.productOfDesktops();
    destopPage.elementFrom_Desktop();
    emailFriend.email_friend();


    }
}
