package ReferFriend;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by User on 23/11/2016.
 */
public class EmailFriend extends DriverManager{

    @FindBy(id ="FriendEmail")
    private WebElement _friendemail;

    @FindBy(id = "PersonalMessage")
    private WebElement _messageTofriend;

    @FindBy(xpath = "//form/div[2]/input")
    private WebElement _sendMail;

    @FindBy(css = "h1")
    private WebElement _actualresult;

    public void email_friend (){

        String refemail = "dost12" + Utility.randomDate() + "@hotmail1.com";  // virtual email ganareter unique
        Utility.typeText(_friendemail,refemail);
        Utility.typeText(_messageTofriend,"you can look for this Product ,May be you like it.");
        Utility.cliclOnElement(_sendMail);

        Assert.assertEquals("Email a friend",Utility.getText(_actualresult));

        System.out.println("Test Pass");




    }
}
