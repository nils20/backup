package ReferFriend;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by User on 23/11/2016.
 */
public class MainPage extends DriverManager {




    @FindBy(name = "Register")
    private WebElement _register;

    @FindBy(linkText= "Computers")
    private WebElement _computerHeader;


    @FindBy(xpath = "//li/ul/li/a")
    private WebElement _destopHeader;

    @FindBy(xpath = "//div[2]/ul/li[2]/a")
    private WebElement _electronicsHeader;

    @FindBy(className = "current-item")
    private WebElement _actualResult;

    public void productOfDesktops()
    {
        Utility.cliclOnElement(_computerHeader);
        Utility.cliclOnElement(_destopHeader);

        Assert.assertEquals("Desktops",Utility.getText(_actualResult));
        System.out.println("User on the Desktops page");
    }
}
