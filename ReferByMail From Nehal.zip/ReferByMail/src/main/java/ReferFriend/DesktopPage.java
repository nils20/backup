package ReferFriend;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by User on 23/11/2016.
 */
public class DesktopPage extends DriverManager {


    @FindBy(xpath = "//div[3]/div/div[2]/h2/a")
    private WebElement _lenova600;

    @FindBy(css = "input.button-2.email-a-friend-button")
    private WebElement _emailFriend;

    @FindBy(css = "h1")
    private WebElement _actulResult;

    public void elementFrom_Desktop () throws InterruptedException {


        Utility.cliclOnElement(_lenova600);
        Utility.cliclOnElement(_emailFriend);

        Assert.assertEquals("Email a friend",Utility.getText(_actulResult));
        System.out.println("user on Email a Friend Page ");

    }

}
