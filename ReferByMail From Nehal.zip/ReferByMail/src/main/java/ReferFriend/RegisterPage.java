package ReferFriend;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by User on 23/11/2016.
 */
public class RegisterPage extends DriverManager {

    @FindBy(linkText = "Register")
    private WebElement _register;

    @FindBy(id ="gender-male")
    private WebElement _genderMale;

    @FindBy(id="gender-female")
    private WebElement _genderFemale;

    @FindBy(id = "FirstName")
    private WebElement _firstName;

    @FindBy(id="LastName")
    private WebElement _lastName;

    @FindBy(name = "DateOfBirthDay")
    private WebElement _birthDay;

    @FindBy(name = "DateOfBirthMonth")
    private WebElement _birthMonth;

    @FindBy(name = "DateOfBirthYear")
    private WebElement _birthYear;

    @FindBy(id="Email")
    private WebElement _email;

    @FindBy(id="Company")
    private WebElement _Company;

    @FindBy(id="Password")
    private WebElement _passWord;

    @FindBy(id="ConfirmPassword")
    private WebElement _confirmPassword;

    @FindBy(id = "register-button")
    private WebElement _registerButton;

    @FindBy(className="result")
    private WebElement _actulResult;


    public  void registerForm() throws InterruptedException {
        Utility.cliclOnElement(_register);
        Utility.cliclOnElement(_genderMale);
        Utility.typeText(_firstName, "Vikram");
        Utility.typeText(_lastName, "Talvar");
        Utility.scrollBy(_birthDay, 5);
        Utility.scrollBy(_birthMonth, 7);

        Utility.scrollBy(_birthYear, 12);
        String email = "ne102" + Utility.randomDate() + "@yahoo1.com";  // virtual email ganareter unique
        Utility.typeText(_email, email);
        System.out.println(email);
        Utility.typeText(_Company, "Vir L.T.D");
        Utility.typeText(_passWord, "1234567Ab");
        Utility.typeText(_confirmPassword, "1234567Ab");
        Utility.cliclOnElement(_registerButton);


        Assert.assertEquals("Your registration completed", Utility.getText(_actulResult));

        System.out.println("Test pass for Register  page");


    }
}
