/**
 * Created by User on 14/11/2016.
 */
public class Line {


  static   void BakaerStreet()
    {
//        String[] line_name = new String[2];
//        line_name[0]="Bakerloo";
//        line_name[1]="Central";
        System.out.println("Balerloo \n  centreal");
    }
}