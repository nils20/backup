import java.util.Objects;
import java.util.Scanner;

/**
 * Created by User on 14/11/2016.
 */
public class Station_Line extends Line {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER STATION NAME FOR TUBE LINE INFO INTO MUST BE IN LOWERCASE: ");
        String station = sc.nextLine();


         String[] station_name=new String[10];
        station_name[0]="aldgate";
        station_name[1]="baker street";
        station_name[2]="bond street";
        station_name[3]="charing cross";
        station_name[4]="euston";
        station_name[5]="green park";
        station_name[6]="holborn";
        station_name[7]="picadally circus";
        station_name[8]="kings cross";
        station_name[9]="waterloo";

        String[] line_name = new String[17];
        line_name[0]="Bakerloo";
        line_name[1]="Central";
        line_name[2]="Circle";
        line_name[3]="Dristrict";
        line_name[4]="Hammersmith & City";
        line_name[5]="Jubilee";
        line_name[6]="Metropolitan";
        line_name[7]="Northern";
        line_name[8]="Piccadilly";
        line_name[9]="Victoria";
        line_name[10]="Waterloo & City";
        line_name[11]="London Overground";
        line_name[12]="Tfl Rail";
        line_name[13]="National Rail";

         // Line b=new Line();

       if(Objects.equals(station, station_name[0]))
        {
                   System.out.println("This Station Have Folling Line \n"+line_name[2]+"\n"+line_name[6]);
       }
else   if(Objects.equals(station, station_name[1]))
        {
            System.out.println("This Station Have Folling Line \n"+line_name[0]+"\n"+line_name[2]+"\n"+line_name[4]+"\n"+line_name[5]+"\n"+line_name[6]);
        }
        else  if(Objects.equals(station, station_name[2]))
       {
           System.out.println("This Station Have Folling Line \n"+line_name[1]+"\n"+line_name[5]);
       }
       else  if(Objects.equals(station, station_name[3]))
       {
           System.out.println("This Station Have Folling Line \n"+line_name[0]+"\n"+line_name[7]+"\n"+line_name[13]);
       }
       else  if(Objects.equals(station, station_name[4]))
       {
           System.out.println("This Station Have Folling Line \n"+line_name[7]+"\n"+line_name[9]+"\n"+line_name[11]+"\n"+line_name[13]);
       }
       else  if(Objects.equals(station, station_name[5]))
       {
           System.out.println("This Station Have Folling Line \n"+line_name[5]+"\n"+line_name[8]+"\n"+line_name[9]);
       }
       else  if(Objects.equals(station, station_name[6]))
       {
           System.out.println("This Station Have Folling Line \n"+line_name[1]+"\n"+line_name[8]);
       }
       else if(Objects.equals(station, station_name[7]))
       {
           System.out.println("This Station Have Folling Line \n"+line_name[0]+"\n"+line_name[8]);
       }
       else  if(Objects.equals(station, station_name[8]))
       {
           System.out.println("This Station Have Folling Line \n"+line_name[2]+"\n"+line_name[4]+"\n"+line_name[6]+"\n"+line_name[7]+"\n"+line_name[8]+"\n"+line_name[9]+"\n"+line_name[13]);
       }
       else  if(Objects.equals(station, station_name[9]))
       {
           System.out.println("This Station Have Folling Line \n"+line_name[0]+"\n"+line_name[5]+"\n"+line_name[7]+"\n"+line_name[10]+"\n"+line_name[13]);
       }
       else
       {
           System.out.println("Out of zone 1 Station");
       }





    }



}


