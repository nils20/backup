/**
 * Created by User on 14/11/2016.
 */
public class Line {

    static   void BakaerStreet()
    {

        System.out.println(" Balerloo \n Circle \n Hammersmith & City \n Jubilee \n Metropolitan");
    }

    static void aldgate(){

        System.out.println(" Circle \n Metropolitan");

    }
    static void   bondStreet(){
        System.out.println(" Central \n Jubilee");
    }

    static void charingCross(){
        System.out.println(" Bakerloo \n Northern \n National Rail");
    }

    static void euston()
    {
        System.out.println(" Northern \n Victoria \n London OvergroundNational Rail");
    }

    static void greenPark(){
        System.out.println("Jubilee \n Piccadilly \n Victoria");
    }

    static void holborn(){
        System.out.println(" Central \n Piccadilly");
    }

    static void picadallyCircus(){ System.out.println(" Balerloo \n Piccadilly"); }
    static void kingsCross()
    {
        System.out.println(" Circle \n Hammersmith & City \nJubilee \n Metropolitan \n Piccadilly \n Victoria \n National Rail");
    }

    static void waterloo(){
        System.out.println(" Bakerloo \n Jubilee \n Northern \n Waterloo & City \n National Rail");

    }

}
