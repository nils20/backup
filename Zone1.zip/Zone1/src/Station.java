import java.util.Objects;
import java.util.Scanner;

/**
 * Created by User on 14/11/2016.
 */
public class Station extends Line {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER STATION NAME FOR TUBE LINE INFO ,MUST BE IN LOWERCASE: ");
        String station = sc.nextLine();


        String[] station_name = new String[10];
        station_name[0] = "aldgate";
        station_name[1] = "baker street";
        station_name[2] = "bond street";
        station_name[3] = "charing cross";
        station_name[4] = "euston";
        station_name[5] = "green park";
        station_name[6] = "holborn";
        station_name[7] = "picadally circus";
        station_name[8] = "kings cross";
        station_name[9] = "waterloo";

        Line b=new Line();

        if(Objects.equals(station, station_name[0]))
        {
            Line.aldgate();
        }
        else  if(Objects.equals(station, station_name[1]))
        {
            Line.BakaerStreet();

        }else  if(Objects.equals(station, station_name[2]))
        {
           Line.bondStreet();
        }
        else  if(Objects.equals(station, station_name[3]))
        {
            Line.charingCross();
        } else  if(Objects.equals(station, station_name[4]))
        {
            Line.euston();

        } else  if(Objects.equals(station, station_name[5]))
        {
          Line.greenPark();
        } else  if(Objects.equals(station, station_name[6]))
        {
           Line.holborn();
        } else  if(Objects.equals(station, station_name[7]))
        {
           Line.picadallyCircus();
        } else  if(Objects.equals(station, station_name[8]))
        {
           Line.kingsCross();
        } else  if(Objects.equals(station, station_name[9]))
        {
          Line.waterloo();
        }  else
        {
            System.out.println("Out of zone 1 Station");
        }


    }
}
