import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

/**
 * Created by User on 14/11/2016.
 */
public class Abc {

    protected static WebDriver driver;
    public static void enterText(By by, String text)
    {
        driver.findElement(by).clear();
        driver.findElement(by).sendKeys(text);
    }

    public static void clickBy(By by){
        driver.findElement(by).click();
    }

    public static void scroll(By by,String a) {
        new Select(driver.findElement(by)).selectByValue(a);
    }

        public static void displayByname(By by,String txt){
        new Select(driver.findElement(by)).deselectByVisibleText(txt);
    }

         public static void indexbylist(By by,int a){
             new Select(driver.findElement(by)).selectByIndex(a);
         }
        //select.selectByValue(a);
    }

