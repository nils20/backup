import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Created by User on 16/11/2016.
 */
public class Gmail_Reg extends Abc{
    public static void main(String[] args) throws InterruptedException {
        driver = new FirefoxDriver();
        /*
        driver.get("https://www.google.com/gmail/about/");
        clickBy(By.xpath("//a[contains(text(),'Create an account')]"));        try but didn't work
        Thread.sleep(3000);
        System.out.println("Page Open");      // check point for page open*/

        driver.get("https://accounts.google.com/SignUp?service=mail&continue=https://mail.google.com/mail/?pc=topnav-about-en");

        Thread.sleep(3000);
        enterText(By.id("FirstName"),"rustam");
        enterText(By.id("LastName"),"khakarawala");
        Thread.sleep(3000);
        enterText(By.id("GmailAddress"),"rustum1289");
        enterText(By.id("Passwd"),"R@m123ram");
        enterText(By.id("PasswdAgain"),"R@m123ram");
        System.out.println("pass wd entered");  // pass wd
        Thread.sleep(3000);


      //  displayByname(By.id("BirthMonth"),"March");
       clickBy(By.id("BirthMonth"));
     //   indexbylist(By.id("BirthMonth"),4);
        enterText(By.id("BirthDay"),"02");
        enterText(By.id("BirthYear"),"1990");
        Thread.sleep(3000);

        displayByname(By.id("Gender"),"Male");


        driver.quit();

    }
}
