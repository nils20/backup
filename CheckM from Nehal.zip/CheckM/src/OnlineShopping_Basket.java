import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Created by User on 15/11/2016.
 */
public class OnlineShopping_Basket extends Abc {

    public static void main(String[] args) throws InterruptedException {
        driver = new FirefoxDriver();
/*
         driver.get("http://www.tesco.com/");
         clickBy(By.id("sign_in_links"));
        clickBy(By.id("grocery-sign-in"));
        enterText(By.id("username"),"test4me00@gmail.com");
        enterText(By.id("password"),"T@ble4@ll1947");
        clickBy(By.className("ui-component__button"));
        System.out.println("User Login Successfully");  // Check point 1 : for login

       // Thread.sleep(3000);
      clickBy(By.id("product-TO_1284175199"));

        clickBy(By.id("id=yui_3_13_0_1_1479304002128_327"));
       System.out.println("selected ");

       // displayByname(By.id("yui_3_13_0_1_1479302349189_327"),"All Fresh Food");
       // Thread.sleep(3000);
*/     //     locater having problem all the time ,even i try from IDE as well

        driver.get("http://www2.hm.com/en_gb/index.html");

        clickBy(By.linkText("Ladies"));
        Thread.sleep(2000);
        clickBy(By.linkText("Clothes"));
        Thread.sleep(2000);
        System.out.println(" User on clothes page");// check point 1

        clickBy(By.linkText("One-shoulder jumpsuit"));
        Thread.sleep(2000);

      /*  scroll(By.xpath("\"//div[@id='swatchsize']/div[2]/ul/li"),"1");
        displayByname(By.xpath("\"//div[@id='swatchsize']/div[2]/ul/"),"1");
       clickBy(By.xpath("//div[@id='swatchsize']/div[2]/ul/li/label/div"));*/

      clickBy(By.xpath("//div[@id='swatchsize']/div[2]/ul/li[2]/label/div"));
       // clickBy(By.id("id=filter-size-0436201003003"));

        Thread.sleep(2000);

        clickBy(By.xpath("//div[2]/button"));

        System.out.println("Product add to basket ");  // product 1 is  Add
        clickBy(By.linkText("Ladies"));

        clickBy(By.linkText("View All"));

        Thread.sleep(2000);

        clickBy(By.linkText("Jersey pencil skirt"));
        Thread.sleep(2000);
        clickBy(By.xpath("//div[@id='swatchsize']/div[2]/ul/li[3]/label/div"));
        Thread.sleep(2000);
        clickBy(By.xpath("//div[2]/button"));

        System.out.println("Product add to basket "); // product 2 add


        clickBy(By.linkText("Men"));
        Thread.sleep(2000);
        clickBy(By.linkText("Clothes"));
        Thread.sleep(2000);
        clickBy(By.linkText("Jersey Henley shirt"));
        Thread.sleep(3000);
        clickBy(By.xpath("//div[@id='swatchsize']/div[2]/ul[2]/li[4]/label/div"));
        Thread.sleep(3000);
        clickBy(By.xpath("//div[2]/button"));
        Thread.sleep(3000);
        System.out.println("Product add to basket ");  // product 3 add
       // clickBy(By.className("goto-shopping-bag rollover-toggle"));
        clickBy(By.xpath("//a[@href='http://www2.hm.com/en_gb/cart']"));

        //clickBy(By.cssSelector("css=a.goto-shopping-bag.rollover-toggle"));


        Thread.sleep(4000);
        scroll(By.id("quantity_filter"),"3");
        Thread.sleep(3000);
   /*     clickBy(By.className("goto-shopping-bag rollover-toggle"));
        Thread.sleep(3000);*/

        String actual = driver.findElement(By.className("box-headline")).getText();
        String expected="SHOPPING BAG TOTAL";

        Assert.assertEquals(actual,expected);

        System.out.println(" Test pass ");

    /*    String actual1 = driver.findElement(By.className("goto-shopping-bag rollover-toggle")).getText();
        String expected2="Shopping bag(6)";

        Assert.assertEquals(expected2, actual1);             try to test pass Assert after 3 product add at end of chekout ????????

        System.out.println(" Test pass ");*/


        driver.quit();


    }
}
