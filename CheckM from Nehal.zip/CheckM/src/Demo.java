import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import static java.lang.Thread.sleep;

/**
 * Created by User on 14/11/2016.
 */
public class Demo extends Abc {

    public static String randomDate () {
        DateFormat format = new SimpleDateFormat("ddMMMyyHHmmss");
        return format.format(new Date());
    }


    public static void main(String[] args) throws InterruptedException {
     //   WebDriver driver=new FirefoxDriver();
        driver=new FirefoxDriver();

        String email="nit"+randomDate()+"@yahoo.com";//  random email generate initilize

        driver.get("http://demo.nopcommerce.com/register");
        sleep(3000);
       // Abc b = new Abc();
        clickBy(By.id("gender-male"));
       enterText(By.id("FirstName"),"Ravan");
       enterText(By.id("LastName"),"ramKapoor");

        scroll(By.name("DateOfBirthDay"),"10");
        scroll(By.name("DateOfBirthMonth"),"3");
        scroll(By.name("DateOfBirthYear"),"1910");
        Thread.sleep(3000);
        System.out.println("DOB ENTER BY USER");//CHECK POINT 1

        enterText(By.id("Email"),email);
        System.out.println(email);          // check point 2
        enterText(By.id("Company"),"Abc ltd");

        Thread.sleep(3000);
        enterText(By.id("Password"),"Abc1234");
        enterText(By.id("ConfirmPassword"),"Abc1234");
        clickBy(By.id("register-button"));
        Thread.sleep(8000);

      String actual = driver.findElement(By.className("result")).getText();
        String expected = "Your registration completed";

        Assert.assertEquals(expected,actual);
        System.out.println("Test Pass ");
        driver.quit();

    }
}
