import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

/**
 * Created by User on 15/11/2016.
 */
public class OrangHrm_Register extends Abc {


    public static void main(String[] args) throws InterruptedException {
        driver =new FirefoxDriver();
        driver.get("http://opensource.demo.orangehrmlive.com/");
          Thread.sleep(3000);

     enterText(By.id("txtUsername"),"Admin");
     enterText(By.id("txtPassword"),"admin");
        Thread.sleep(3000);
     clickBy(By.id("btnLogin"));
        Thread.sleep(3000);
     System.out.println("user login");                                  // check point 1: user login


       clickBy(By.id("menu_pim_viewPimModule"));
       clickBy(By.id("btnAdd"));
        System.out.println("user on Add User Page ");                 //  Check point 2 : user on user Add page

      Thread.sleep(3000);

        //scroll(By.id("systemUser_userType"),"0");              //enter value like 0 or 1
       // new Select(driver.findElement(By.id("systemUser_userType"))).selectByVisibleText("ESS");
        Thread.sleep(3000);
        System.out.println("name enter ");
        enterText(By.id("firstName"),"Raja ");
        enterText(By.id("middleName"),"Babu");
        enterText(By.id("lastName"),"Zoravar");
        enterText(By.id("employeeId"),"00007");

        System.out.println("user enter personal detail"); // check point 3 : personal detail
        clickBy(By.id("chkLogin"));


        enterText(By.id("user_name"),"raja0007");

        enterText(By.id("user_password"),"Abc1234");
        enterText(By.id("re_password"),"Abc1234");
        System.out.println("password succesfully enter "); // check pont 4 for password

        driver.findElement(By.id("status")).isEnabled();

        clickBy(By.id("btnSave"));

        System.out.println("User Create His Account ");        //Check point 5: user create his account
        Thread.sleep(3000);

        //scroll(By.id("welcome"),"1");
       // new Select(driver.findElement(By.id("welcome"))).selectByVisibleText("Logout");
        clickBy(By.id("welcome"));
       clickBy(By.linkText("Logout"));
        Thread.sleep(3000);
        System.out.println("User Scuccefull logout from his account");

        enterText(By.id("txtUsername"),"raja0007");        // Check point 6 : relogin
        enterText(By.id("txtPassword"),"Abc1234");
        Thread.sleep(3000);
        clickBy(By.id("btnLogin"));
        Thread.sleep(3000);





         String actual= driver.findElement(By.id("welcome")).getText();   // Check point for Assert
         String expected="Welcome Raja";

        Assert.assertEquals(actual,expected);
        System.out.println("Test Pass");


        driver.quit();



    }
}
