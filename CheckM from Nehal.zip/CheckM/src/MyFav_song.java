import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Created by User on 16/11/2016.
 */
public class MyFav_song extends Abc {
    public static void main(String[] args) throws InterruptedException {
        driver = new FirefoxDriver();

       // WebDriverWait wait = new WebDriverWait(driver,50000);

        driver.get("https://www.youtube.com/watch?v=FxAG_11PzCk");
        Thread.sleep(400000);

        driver.quit();

    }
}
